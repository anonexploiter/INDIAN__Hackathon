import subprocess
output = subprocess.getoutput(" g++ -g question.cpp -o 1 && echo '15 1 2 3 4 5 6 7 8 9 10 11 12 14 1222 '| ./1 > output.txt")
print(output)