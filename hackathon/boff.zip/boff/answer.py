import subprocess
output = subprocess.getoutput(" g++ question.cpp -o 1 && echo '11'| ./1 > output.txt")
print(output)