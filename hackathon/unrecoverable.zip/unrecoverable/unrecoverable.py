import subprocess
n=input("enter the path of your file : ")
output = subprocess.getoutput("./sdelete -s n")
print("deleted sucessfully")