import pickle
import hmac
import hashlib

def reverse_fun():
    with open("users.json","rb") as f:
        data = f.read()      
    try:
        safecode,string = data.split(bytes('-','utf-8'))
    except ValueError:
        return "empty json"
      
    d = hmac.new(bytes('S3cR37_M5G','utf-8'),safecode,hashlib.sha256).hexdigest()
      
    if hmac.compare_digest(string,bytes(d,'utf-8')):
          d = pickle.loads(safecode)
          return d
    else:
          return "Invalid flag"

if __name__ == '__main__':
      print(reverse_fun())
